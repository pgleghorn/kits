Oracle WebCenter Sites Support Tools 4.4
========================================


ABOUT
-----

The WebCenter Sites Support Tools are intended for use by experienced users
with SiteGod privileges to assist in audit, cleanup, help diagnose and resolve
problems.

THE USE OF SUPPORT TOOLS ARE NOT COVERED UNDER THE ORACLE MAINTENANCE &
SUPPORT AGREEMENTS, AND ARE NOT INTENDED TO BE USED IN CONNECTION WITH ANYTHING
OTHER THAN ORACLE SOFTWARE.


INSTALLATION
------------

a) using SitesExplorer (formerly ContentServer Explorer)

 - Open SitesExplorer and log into Sites
 - Import the Support Tools zip file by going to File > Import > Project
 - Allow SitesExplorer to finish importing
 - After it returns "Project Import Successful" go to File > Save All
 - Log in by going to Projects > Support > SiteCatalog or
   Tables > SiteCatalog > Support
 - Right click the dot to the left of Home, click Preview Page, then OK

b) using CatalogMover

 - Unzip SupportTools zip file
 - Go to Sites installation directory, run catalogmover.sh /
   catalogmover.bat and connect to Sites
 - On the CatalogMover menu, use Catalog > Auto Import Catalog(s)
 - In the dialog "Select base directory for import", choose the directory
   created by unzipping the SupportTools. This should contain 
   ElementCatalog.html, SiteCatalog.html and others.
 - Click Save, and OK the next dialog


UNINSTALLATION
--------------

a) using SitesExplorer (formerly ContentServer Explorer)

 - Open SitesExplorer and log into Sites.
 - Expand the Projects folder and the subsequent Support folder.
 - Under the Projects > Support folder, delete the SiteCatalog folder.
 - Under Projects > Support, delete the ElementCatalog folder.
 - Under Projects > Support, delete the SystemSQL folder.
 - Under Projects, delete the Support folder.
 - Choose File - Save All. 

b) quick uninstallation (only applicable to version 4.1 onwards)

 - Log into Support Tools with a SiteGod user
 - Goto "Info" on the menu, and select "Uninstall"
 - Review the list of what will be deleted
 - Enter "I know what I am doing" into the input field and press Submit


UPGRADE
-------

To upgrade, you must first remove any previous installations of Support
Tools, and then install the new version. Please follow steps under
UNINSTALLATION and then INSTALLATION.


DISCLAIMER
----------

"Support Tools" are a set of diagnostic tools distributed to licensed users
for use only under the direct supervision and guidance of a member of the
support team. Incorrect usage of the Support Tools may cause permanent damage
to the software.  UNDER NO CIRCUMSTANCES SHOULD THE SUPPORT TOOLS BE USED
INDEPENDENTLY BY A CUSTOMER OR PARTNER FOR ANY REASON THE USE OF SUPPORT
TOOLS ARE NOT COVERED UNDER THE MAINTENANCE & SUPPORT AGREEMENTS, ARE NOT
INTENDED TO BE USED IN CONNECTION WITH ANYTHING OTHER THAN THE SOFTWARE THE
TOOLS ARE INTENDED FOR, AND ARE ONLY TO BE USED UNDER THE DIRECTION OF THE
TECHNICAL SUPPORT TEAM.
